# Some Notes on Some Java THings

## Environment Variables

RapidEE is good.  Its on Choco.

`JAVA_HOME = C:\Program Files\Java\jdk1.8.0_181`  It should point to the JDK
`JDK_HOME = C:\Program Files\Java\jdk1.8.0_181` Is the same.  This can be a JRE or a JDK, but I believe a JDK takes preference.
`JRE_HOME = C:\Program Files\Java\jre1.8.0_181`
`M2` = Maven
## Generics

Will only work with classes not base types (eg. int, vs. Integer())
