So I lost data for Monday -Wednesday from this week due to my computer failing the update. One of the things I stopped was my time logger.

But on Monday I spend 6 hours getting my computer back. Part of it- maybe 3 hours, I had Ron hammering away at it. That was after I tried for 2 hours. Then after he gave up, I just rolled it back from the backup I made Thursday- which took an hour.

On Thursday 12/13 I spent most the day backing up the computer, because I knew over the weekend it would try and update again and likely fail. I also was uninstalling everything on my computer, thinking its a program or setting interfering. I spent some time on the internet researching the problem as well.
**4.5** hrs work that day
**22.4% of** my time in Windows Settings.
**19.3%** in Windows Explorer
**12.3%** in Chrome (researching fixes to no avail)
**5.5% in** Glary Utilities (a program uninstaller, and windows repair utility)
**4.7%** of my time in 7-zip (backing things up
**4%** of my time at the command prompt
**3%** of my time was in Windows Backup
and **3.5%** of my time is in Aoemi Backup
The remainder are all small percentages an are uninstallers or backup programs. +**1hr at CUH**

Wednesday, 12/12 we had Conferance in the AM,
I was **present 7am - until 10:02** I logged into my PC.
From **10:02 - 11:09 AM** I entered cases.
From **11:09- 12:54** we had our meeting
From **12:54 to 3:02** I matched the cases for Doolabh from Scotts list. I am the only one who knows how to do this. Though Ron was looking over my shoulder for most of it so hopefully he recalls for the future. I also showed Phillip this week. I was able to find the value that Scott had pulled to number the cases. I am also the only one that knows how to pull tabular data from Epic and rapidly compare it (see above for caveat). This is value added work for the group, but also a "distraction"
**30 min of** this was summarizing my findings in emails to Ron, and to Toby. Toby corrected 2 errors- though incredibly irritatingly he denied any errors (he had the wrong surgeon) and when Ron came and said 2 cases needed to be entered that turned up missing, I said I would enter them because the last time I asked Sameera for help I was over-ruled. And I did not want to add to the backlog to Toby- even though I knew it would add to mine.

**3:02-3:24** I ran a report on the number of cases I completed each week. Demonstrating the repeated and frustrating claims of "no-evidence of work" or "minimal effort" or "continuous distractions" to be at best a gross- over-exaggeration.

**3:24-4:27 -** I presented this data. I reminded myself why its futile to bring the work I do to you - which is one reason I don't think you know what the "distractions" are. It receives a cursory glance, and then we go back to the charts that I was trying to refute. I thought there was a modicum of understanding there, only we were to repeat it again a week later. Discussing the exact same issue. Where you turned, determined to prove that I underperform, and see that just as my simple query showed, completed 2x the (CUH cases of Toby and Sameera the past 2 months.)

**4:37-8:22 I** enter cases. There are no other programs open, except for the audible app in the background, and OneNote, where I add a note on the decision to code DelNido as Both and document a start date, to start formalizing the decisions made in Wednesday meetings.

I have no documented breaks, except those that may have been taken before or after our two meetings.

## Tuesday Dec 11

Login at 909- Immedietly open Epic and Armus.
From **9:20-11:00** I am emailing IR Support and then speaking with them on the phone. I've lost CVTS tab access.
11:04-11:27 I am away. I did not document what- bathroom or maybe down to the pharmacy. I dont recall.
**11:27-12:49** I am entering cases.
**12:49-1:07** there is another break.
**From 1:07- to 6:16** I am entering cases. I spend a small amount of time in OneNote, continuing to annotate the best sources for things and work on a check list for complications (I discussed it with you on wed the 12th, but Ive been working on it for a few months.) Toby refuses any changes, but when we get a new person they will be trained, like Sameera is, in the method of efficiently gathering data, that is quick and misses nothing. The old way of entering cases that I was taught when I started is not good, its what takes Toby so much time. From Jan-Feb of this year, I spent a lot of my "distracted" time developing this. The restrictions placed on my time this year in Jan w/ restrictions on research projects and in April w/ restrictions in hours made me realize that this is not a long term job prospect. Its meant to be an admin job. Still, I always give 100% and I will at least leave you guys with this process, if I am not able to automate it.

72.5% of my time that day was spent in Epic and Armus
11.4% in Outlook
10.6% in OneNote
1.6% in the Audible App (my background book on tape)
1.3% of my time on Chrome

Any way,
I am not going to do every day like this, I have much more detail than this, including every site I visit, and what I do in each application. Its all stored.

Broader Strokes.
Last Thursday, I spent from 7:18 AM to 12:46 working on the stuff for Bonnie. This included a 23 minute discussion with you. And another 15 minute one.
12:46-1:09 I am checking each of the cases in Epic
4x that day I start to enter cases, then either Ron or Bonnie and finally Dr. Jessen comes over and either needs something done or checked or changed.

Ron comes over 3 x and asks me to change a single value in outcomes. Something he could have done himself, since presumably he was looking at outcomes, but it comes to me. I discuss with Ron and need to change the excel sheet, then bonnie wants explinations of all the changes which I provide. Then Ron wants the file adjusted slightly and resaved. So I redo it. Then Dr. Jessen wants the explinations explained.
**Overall, my work (distractions) that day saves the department \$37,500.** And if they would agree to make the TAVR and Antibiotic Exclusion as I suggest, they could call it an even \$50,000.
These
That day I spend:
38.8% of my time in Excel
21.0% in Outlook
13% in Epic
10% in Armus
1.3 % in Acrobat
And a significant undocumented percent in face to face
Total 'Distractions' 9h 59 min

Wed 12/5

I started looking at the Parkland data however the day prior, on Wednesday. A day that started at 6:30 am.

From 3:47- 4:20 I am talking to Ron and Bonnie.
At 6:48 pm- 10:31pm I am looking at each of our antibiotic cases that are "nos", I am researching the SCIP measures, and and I am checking Ron's spreadsheet and preparing emails.

Total "distractions" that day: 4 hr 13 min.

Tues 12/2

Ginger asks for help interpreting a few operative reports. I am not familiar, I answer her. Then consult an anatomy text and a paper and finally understand what Dr. Kernstein did - (The answer was a trisegmentectomy + lingualar lobe = a whole lobe. There is no faculty around to refer this question to.) Total time is 1.5 hrs.

Mon Dec 3

I come in late, have a Dr. Apt in the AM

From 1:28 - 2:07 I work on updates to the quick entry form that we will be switching too after Toby's retirement.
I add check boxes for NTpBNP, HIT, PreAlb, MvSO2, Lactate, and reminders to check for Head CT and US of extremities.

Thursday Nov 29th
I've been thinking about how you told me you see no evidence of work from me (just after I reminded you that I was on vacation for that week except 1 day.) Cant concentrate. Write letter from 2:45 -3:30 to express frustration and wonder how our relative perceptions can differ so greatly, where my family is pleading with me to quit working so much. (I had a mini-intervention while home for Thanksgiving) and at work I am continuously told Im hardly working

Anyway, it goes on.

Other things Ive been asked to do recently.

I guess you never got back to Sarah with the Cytosorbants data. I refered that to you as asked, but she said she never got anything from you. So I pulled it. It took around 7 hours.

Lea Rhea needed data on TAVRs for some meeting. It was just quick stuff. Took about an hour.

Clinical Trials needed help stripping private date from DICOM files. That was hard to do. But I figured it out and showed them how to do that for the future. About 4.5 hours.
